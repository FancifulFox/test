#include<iostream>
#include"workerManager.h"
#include"worker.h"
#include"employee.h"
#include"Manager.h"
#include"boss.h"
using namespace std;
int main() {
	/*Worker* worker = NULL;66y
	worker = new Employee(1, "����", 1);
	worker->showInfo();
	delete worker;
	worker = new Manager(2, "����", 2);
	worker->showInfo();
	delete worker;
	worker = new Boss(3, "����", 3);
	worker->showInfo();
	delete worker;*/
	WorkerManager wm;
	int choice = 0;
	while (true) {
		wm.Show_Menu();
		cout << "����������ѡ��" << endl;
		cin >> choice;
		switch (choice) {
		case 0://�˳�
			wm.Exitsystem();
			break;
		case 1://����
			wm.Add_Emp();
			break;
		case 2://��ʾ
			wm.showemp();
			break;
		case 3://ɾ��
			wm.deletmem();
			break;
		case 4://�޸�
			wm.modify();
			break;
		case 5:///����
			wm.sort_emp();
			break;
		case 6://���
			wm.clean_emp();
			break;
		default:
			system("cls");
			break;
		}
	}
	
	system("pause");
	return 0;
}